Cara Instal Code :

1. Download file Source code melalui halaman https://github.com/bagindaharahap/bersamamu
2. Ekstrak File ke dalam folder tertentu
3. Buka melalui teks editor seperti Visual Studio Code
4. run melalui browser Google Chrome (Disarankan)
   

